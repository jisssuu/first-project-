//
//  Sample1App.swift
//  Sample1
//
//  Created by 홍길동 on 2022/07/11.
//

import SwiftUI

@main
struct Sample1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
